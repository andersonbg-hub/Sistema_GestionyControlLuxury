import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin_screen.dart';
import 'app_widgets.dart';
import 'models.dart';
import 'service_screen.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const publishableKey = String.fromEnvironment(
    'SUPABASE_PUBLISHABLE_KEY',
    defaultValue: String.fromEnvironment('SUPABASE_ANON_KEY'),
  );
  String? initializationError;
  SupabaseClient? client;
  if (url.isNotEmpty || publishableKey.isNotEmpty) {
    if (url.isEmpty || publishableKey.isEmpty) {
      initializationError =
          'Configura SUPABASE_URL y SUPABASE_PUBLISHABLE_KEY juntos para habilitar la conexión.';
    } else {
      try {
        await Supabase.initialize(url: url, publishableKey: publishableKey);
        client = Supabase.instance.client;
      } catch (error) {
        initializationError = 'No se pudo inicializar Supabase: $error';
      }
    }
  }
  runApp(LuxuryApp(client: client, initializationError: initializationError));
}

class LuxuryApp extends StatefulWidget {
  const LuxuryApp({super.key, this.client, this.initializationError});
  final SupabaseClient? client;
  final String? initializationError;

  @override
  State<LuxuryApp> createState() => _LuxuryAppState();
}

class _LuxuryAppState extends State<LuxuryApp> {
  late final RestaurantStore store = RestaurantStore(client: widget.client);

  @override
  void initState() {
    super.initState();
    unawaited(store.initialize());
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Luxury · Restaurante Oriental',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: luxuryBrown,
        primary: luxuryBrown,
        secondary: luxuryGold,
        error: luxuryRed,
        surface: luxuryBone,
      ),
      scaffoldBackgroundColor: luxuryBone,
      appBarTheme: const AppBarTheme(
        backgroundColor: luxuryBrown,
        foregroundColor: Colors.white,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFFE8DED6)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE8DED6)),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: luxuryGold,
          foregroundColor: const Color(0xFF241010),
          minimumSize: const Size(44, 44),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(11),
          ),
        ),
      ),
      navigationRailTheme: const NavigationRailThemeData(
        backgroundColor: Colors.white,
        selectedIconTheme: IconThemeData(color: luxuryBrown),
        selectedLabelTextStyle: TextStyle(
          color: luxuryBrown,
          fontWeight: FontWeight.w700,
        ),
      ),
    ),
    home: _RootScreen(store: store, startupError: widget.initializationError),
  );
}

class _RootScreen extends StatelessWidget {
  const _RootScreen({required this.store, this.startupError});
  final RestaurantStore store;
  final String? startupError;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (context, _) {
      if (store.loading) {
        return const Scaffold(
          body: Center(child: CircularProgressIndicator(color: luxuryGold)),
        );
      }
      if (startupError != null) {
        return Scaffold(
          body: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: ErrorBanner(message: startupError!),
              ),
            ),
          ),
        );
      }
      if (store.role == null) return _LoginScreen(store: store);
      return _WorkScreen(store: store);
    },
  );
}

class _LoginScreen extends StatefulWidget {
  const _LoginScreen({required this.store});
  final RestaurantStore store;

  @override
  State<_LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<_LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? error;
  RestaurantStore get store => widget.store;

  Future<void> _login(StaffRole role) async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await store.loginDemo(role);
    } catch (exception) {
      setState(() => error = '$exception');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _signIn() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await store.signIn(email.text.trim(), password.text);
    } catch (exception) {
      setState(() => error = '$exception');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 900;
        return Row(
          children: [
            if (!narrow)
              Expanded(
                child: Container(
                  color: luxuryBrown,
                  padding: const EdgeInsets.all(54),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Spacer(),
                      Container(
                        width: 68,
                        height: 68,
                        decoration: BoxDecoration(
                          color: luxuryGold,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(
                          Icons.restaurant,
                          size: 36,
                          color: luxuryBrown,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'LUXURY',
                        style: Theme.of(context).textTheme.displaySmall
                            ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 4,
                            ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Una mesa. Todo el servicio.',
                        style: TextStyle(
                          color: Color(0xFFF5D7B8),
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Administración, cocina y atención conectadas en una sola plataforma.',
                        style: TextStyle(color: Colors.white70, height: 1.5),
                      ),
                      const Spacer(),
                      Text(
                        store.isConnected
                            ? 'SUPABASE · CONECTADO'
                            : 'RESTAURANTE ORIENTAL · CHINCHA',
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 11,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 480),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (narrow) ...[
                          const Icon(
                            Icons.restaurant,
                            size: 40,
                            color: luxuryBrown,
                          ),
                          const SizedBox(height: 14),
                        ],
                        Text(
                          store.isConnected
                              ? 'Iniciar sesión'
                              : 'Bienvenido a Luxury',
                          style: Theme.of(context).textTheme.headlineMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          store.isConnected
                              ? 'Usa tu cuenta autorizada de Supabase Auth.'
                              : 'Elige el espacio de trabajo para recorrer la demostración.',
                        ),
                        const SizedBox(height: 24),
                        if (store.errorMessage != null) ...[
                          ErrorBanner(message: store.errorMessage!),
                          const SizedBox(height: 12),
                        ],
                        if (error != null) ...[
                          ErrorBanner(message: error!),
                          const SizedBox(height: 12),
                        ],
                        if (store.isConnected) ...[
                          TextField(
                            controller: email,
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(
                              labelText: 'Correo',
                              prefixIcon: Icon(Icons.alternate_email),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: password,
                            obscureText: true,
                            onSubmitted: (_) => _signIn(),
                            decoration: const InputDecoration(
                              labelText: 'Contraseña',
                              prefixIcon: Icon(Icons.lock_outline),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton(
                              onPressed: busy ? null : _signIn,
                              child: Text(
                                busy ? 'Conectando…' : 'Iniciar sesión',
                              ),
                            ),
                          ),
                        ] else ...[
                          ...StaffRole.values.map(
                            (role) => Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Card(
                                child: ListTile(
                                  onTap: busy ? null : () => _login(role),
                                  leading: CircleAvatar(
                                    backgroundColor: luxuryGold.withValues(
                                      alpha: .15,
                                    ),
                                    child: Icon(
                                      _roleIcon(role),
                                      color: luxuryBrown,
                                    ),
                                  ),
                                  title: Text(
                                    role.label,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  subtitle: Text(_roleDescription(role)),
                                  trailing: busy
                                      ? const SizedBox.square(
                                          dimension: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : const Icon(
                                          Icons.arrow_forward_ios,
                                          size: 15,
                                        ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Modo local de demostración: los cambios se conservan en este dispositivo y no se envían a Supabase.',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    ),
  );

  static IconData _roleIcon(StaffRole role) => switch (role) {
    StaffRole.administrator => Icons.space_dashboard_outlined,
    StaffRole.manager => Icons.manage_accounts_outlined,
    StaffRole.kitchen => Icons.soup_kitchen_outlined,
    StaffRole.headChef => Icons.restaurant_menu,
    StaffRole.waiter => Icons.table_restaurant,
    StaffRole.cashier => Icons.point_of_sale,
  };

  static String _roleDescription(StaffRole role) => switch (role) {
    StaffRole.administrator =>
      'Dashboard, menú, inventario, usuarios y reportes',
    StaffRole.manager => 'Reportes, incidencias, usuarios y auditoría',
    StaffRole.kitchen => 'Comandas en vivo, disponibilidad y faltantes',
    StaffRole.headChef => 'Comandas, alertas, disponibilidad y solicitudes',
    StaffRole.waiter => 'Mesas, pedidos, observaciones y seguimiento',
    StaffRole.cashier => 'Pagos mixtos, notas de venta y arqueo',
  };
}

class _WorkScreen extends StatelessWidget {
  const _WorkScreen({required this.store});
  final RestaurantStore store;

  Future<void> _resetDemo(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reiniciar demostración'),
        content: const Text(
          'Se eliminarán los cambios locales y volverán los datos de ejemplo.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Reiniciar'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      try {
        await store.resetDemo();
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Demostración reiniciada.')),
          );
        }
      } catch (error) {
        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('$error')));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final role = store.role!;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(
          children: [
            const Icon(Icons.restaurant, color: luxuryGold),
            const SizedBox(width: 10),
            const Text(
              'LUXURY',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5),
            ),
            const SizedBox(width: 12),
            if (MediaQuery.sizeOf(context).width > 650)
              Text(
                '· ${role.label}',
                style: const TextStyle(fontSize: 14, color: Colors.white70),
              ),
          ],
        ),
        actions: [
          if (MediaQuery.sizeOf(context).width > 600)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Chip(
                avatar: Icon(
                  store.isConnected ? Icons.cloud_done : Icons.wifi_off,
                  size: 17,
                ),
                label: Text(store.isConnected ? 'Supabase' : 'Demo local'),
                visualDensity: VisualDensity.compact,
              ),
            ),
          PopupMenuButton<String>(
            tooltip: store.displayName,
            icon: const Icon(Icons.account_circle_outlined),
            onSelected: (value) {
              if (value == 'logout') unawaited(store.signOut());
              if (value == 'reset') unawaited(_resetDemo(context));
            },
            itemBuilder: (context) => [
              PopupMenuItem<String>(
                enabled: false,
                value: 'account',
                child: Text('${store.displayName}\n${role.label}'),
              ),
              if (store.isDemo)
                const PopupMenuItem(
                  value: 'reset',
                  child: Text('Reiniciar demostración'),
                ),
              const PopupMenuItem(
                value: 'logout',
                child: Text('Cerrar sesión'),
              ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: switch (role) {
        StaffRole.administrator => AdminScreen(store: store),
        StaffRole.manager => AdminScreen(store: store, managerOnly: true),
        StaffRole.kitchen => KitchenScreen(store: store),
        StaffRole.headChef => KitchenScreen(store: store),
        StaffRole.waiter => WaiterScreen(store: store),
        StaffRole.cashier => CashierScreen(store: store),
      },
    );
  }
}
